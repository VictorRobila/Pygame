This game requires a Python interpreter to run of version at least 3.8.
Run the game either by double-clicking neverending.py on Windows or by using
the run_game.py file.

Team Untitled:
Victor Robila (Team Leader, Programmer)
Sam Huang (Programmer)
Sophie Cheng (Artist)

Controls:
Left and right arrows to move left and right.
Space to jump.
Mouse used to aim staff.
E used to shoot staff.
Mouse used to click buttons.

The main menu has a few options. In the settings, you can change music volume
or difficulty. In the shop, you can get upgrades as you progress through the
game. The tutorial is just a tutorial giving the basic controls and info
about the game. The credits show, well, credits. The game can be quit with
the quit button.

After pressing play, the game consists of randomly generated rooms. These
all have the same background and floor but with random terrain. Enemies will
spawn that lower health when touched. Every 5 rooms is a checkpoint room, so
when you die, you don't lose too much progress.

Copyright Attributions:
This game uses Voyage by Ben Reber for the song.